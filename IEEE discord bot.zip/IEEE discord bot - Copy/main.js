const { GatewayIntentBits } = require('discord.js');
const Discord = require('discord.js');
const Bot = new Discord.Client({
    intents: [
        GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent,
    ],
});

var naptime = 0;

Bot.once('ready', () => {
    console.log('Bot online');
});
Bot.login('MTAyMjE4Mjg2MjQ2NTc5ODE5OA.GCQ_xR.d9NSW6f4W4wr937td9KygOWLYrn9_3HmqzqUYs');

Bot.on('messageCreate', function (msg) {
    if (msg.content.toLowerCase() == 'hi jerry') {
        wakeUp();
        msg.channel.send('bork.');
        naploop(20);
    } else if (msg.content.toLowerCase() == 'hey jerry') {
        wakeUp();
        msg.channel.send('howdy :(');
        naploop(5);
    } else if (msg.content.toLowerCase() == 'salutations jerry') {
        wakeUp();
        msg.channel.send('salutations.');
        naploop(30);
    } else {
        console.log('error');
    }//if
});

function wait(ms) {
    const date = Date.now;
    let currentdate = null;
    do {
        currentdate = Date.now;
    } while (currentdate - date < ms);
}//wait

function naploop(time) {
    naptime = time * 1000;
    for (var i = naptime; i >= 0 ; i--) {
        wait(500);    
    }//for
    Bot.user.setActivity('Napping simulator');
}//naploop

function wakeUp() {
    Bot.user.setActivity('');
}//wakeup